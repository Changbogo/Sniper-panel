# Changbogo Sniper Panel

Bu panel, kaldıraçlı işlemlerde otomatik giriş, SL ve TP takibi yapar.